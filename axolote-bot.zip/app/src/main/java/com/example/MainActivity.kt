package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Coffee
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Handshake
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Mood
import androidx.compose.material.icons.filled.MoodBad
import androidx.compose.material.icons.filled.Paid
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import coil.compose.AsyncImage
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.ChatViewModel
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import android.graphics.BitmapFactory
import android.util.Base64
import androidx.compose.ui.graphics.asImageBitmap

// Theme changed to Yellow and Orange as requested
val NeonPink = Color(0xFFFF5722) // Deep orange
val NeonCyan = Color(0xFFFFC107) // Amber/Yellow
val NeonGreen = Color(0xFFFF9800) // Orange
val DarkNavy = Color(0xFF2E1500) // Dark brownish orange background
val CardCharcoal = Color(0xFF4E2100) // Lighter brown/orange card
val MattePurple = Color(0xFFFF9800) // Used for user bubble
val TextLight = Color(0xFFFFF3E0) // Light orange text
val BorderAccent = Color(0xFF7A3700)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = DarkNavy
                ) {
                    ChatScreen()
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(viewModel: ChatViewModel = viewModel()) {
    val messages by viewModel.messages.collectAsStateWithLifecycle()
    val stats by viewModel.userStats.collectAsStateWithLifecycle()
    val isLoading by viewModel.isLoading.collectAsStateWithLifecycle()
    val botAvatarUri by viewModel.botAvatarUri.collectAsStateWithLifecycle()
    val chatSessions by viewModel.chatSessions.collectAsStateWithLifecycle()
    val currentSessionId by viewModel.currentSessionId.collectAsStateWithLifecycle()

    var textInput by remember { mutableStateOf("") }
    var showsNameDialog by remember { mutableStateOf(false) }
    var currentNameInput by remember { mutableStateOf("") }

    val listState = rememberLazyListState()
    val keyboardController = LocalSoftwareKeyboardController.current
    val context = LocalContext.current
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val coroutineScope = rememberCoroutineScope()

    val imagePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent(),
        onResult = { uri ->
            uri?.let {
                viewModel.updateBotAvatar(it.toString())
            }
        }
    )

    // Auto scroll to bottom when messages list size changes
    LaunchedEffect(messages.size, isLoading) {
        if (messages.isNotEmpty()) {
            delay(100)
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    val username = stats?.username ?: "Insignificante"

    ModalNavigationDrawer(
        drawerState = drawerState,
        gesturesEnabled = true,
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = CardCharcoal,
                drawerContentColor = TextLight,
                modifier = Modifier.width(300.dp)
            ) {
                Spacer(modifier = Modifier.height(16.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "Histórico",
                        style = MaterialTheme.typography.titleLarge,
                        color = NeonCyan,
                        fontWeight = FontWeight.Bold
                    )
                    IconButton(onClick = {
                        viewModel.createNewSession()
                        coroutineScope.launch { drawerState.close() }
                    }) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = "Novo Chat", tint = NeonGreen)
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                LazyColumn(modifier = Modifier.fillMaxSize()) {
                    items(chatSessions) { session ->
                        val isSelected = session.id == currentSessionId
                        NavigationDrawerItem(
                            label = { 
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = session.title,
                                        overflow = TextOverflow.Ellipsis,
                                        maxLines = 1,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    IconButton(
                                        onClick = { viewModel.deleteSession(session.id) },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Delete,
                                            contentDescription = "Excluir Chat",
                                            tint = NeonPink,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            },
                            selected = isSelected,
                            onClick = {
                                viewModel.switchSession(session.id)
                                coroutineScope.launch { drawerState.close() }
                            },
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                            colors = NavigationDrawerItemDefaults.colors(
                                unselectedContainerColor = Color.Transparent,
                                selectedContainerColor = DarkNavy,
                                selectedTextColor = NeonCyan,
                                unselectedTextColor = TextLight
                            )
                        )
                    }
                }
            }
        }
    ) {
        Scaffold(
            modifier = Modifier,
            topBar = {
                Column(
                    modifier = Modifier
                        .background(CardCharcoal)
                        .statusBarsPadding()
                        .padding(horizontal = 8.dp, vertical = 12.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = { coroutineScope.launch { drawerState.open() } },
                            colors = IconButtonDefaults.iconButtonColors(contentColor = Color.LightGray)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Menu,
                                contentDescription = "Menu de histórico",
                                tint = NeonCyan
                            )
                        }
                        
                        // Avatar of Axolote Bot
                        Box(
                            modifier = Modifier
                                .size(54.dp)
                                .clip(CircleShape)
                                .border(2.dp, NeonCyan, CircleShape)
                                .clickable {
                                    try {
                                        imagePickerLauncher.launch("image/*")
                                    } catch (e: Exception) {
                                        e.printStackTrace()
                                    }
                                }
                        ) {
                            AsyncImage(
                                model = botAvatarUri ?: R.drawable.cool_axolote_avatar_1782170240859,
                                contentDescription = "Axolote Bot Smirk Face",
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                        }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(modifier = Modifier.weight(1.0f)) {
                        Text(
                            text = "Axolote Bot",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextLight,
                                fontSize = 18.sp
                            )
                        )
                        Row(
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(if (isLoading) NeonPink else NeonGreen)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (isLoading) "pensando..." else "doido do mine robô",
                                color = TextLight.copy(alpha = 0.8f),
                                fontSize = 12.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    // Edit Username Button
                    IconButton(
                        onClick = {
                            currentNameInput = username
                            showsNameDialog = true
                        },
                        colors = IconButtonDefaults.iconButtonColors(contentColor = Color.LightGray)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = "Mudar apelido",
                            tint = NeonCyan
                        )
                    }

                    // Clear conversation button
                    IconButton(
                        onClick = { viewModel.clearChat() },
                        colors = IconButtonDefaults.iconButtonColors(contentColor = Color.LightGray)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Limpar conversa",
                            tint = NeonPink.copy(alpha = 0.8f)
                        )
                    }
                }
            }
        },
        containerColor = DarkNavy
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Messages Chat Box
                LazyColumn(
                    state = listState,
                    modifier = Modifier
                        .weight(1.0f)
                        .fillMaxWidth(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    if (messages.isEmpty()) {
                        item {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 40.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(100.dp)
                                        .clip(CircleShape)
                                        .background(CardCharcoal)
                                        .border(2.dp, NeonPink, CircleShape)
                                        .padding(8.dp)
                                ) {
                                    AsyncImage(
                                        model = botAvatarUri ?: R.drawable.cool_axolote_avatar_1782170240859,
                                        contentDescription = "Axolote Bot Smirk Face",
                                        modifier = Modifier.fillMaxSize(),
                                        contentScale = ContentScale.Crop
                                    )
                                }
                                Spacer(modifier = Modifier.height(16.dp))
                                Text(
                                    text = "O Axolote Bot está entediado.",
                                    color = TextLight,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 18.sp
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "Faça uma pergunta burra para ele detonar você com todo o charme.",
                                    color = TextLight.copy(alpha = 0.6f),
                                    textAlign = TextAlign.Center,
                                    fontSize = 13.sp,
                                    modifier = Modifier.padding(horizontal = 24.dp)
                                )
                            }
                        }
                    } else {
                        items(messages) { message ->
                            val isUser = message.sender == "user"
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
                            ) {
                                if (!isUser) {
                                    // Axolote Bot Small circular avatar
                                    Box(
                                        modifier = Modifier
                                            .size(34.dp)
                                            .clip(CircleShape)
                                            .border(1.dp, NeonCyan, CircleShape)
                                    ) {
                                        AsyncImage(
                                            model = botAvatarUri ?: R.drawable.cool_axolote_avatar_1782170240859,
                                            contentDescription = "Axolote Bot Face",
                                            modifier = Modifier.fillMaxSize(),
                                            contentScale = ContentScale.Crop
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                }

                                Card(
                                    modifier = Modifier
                                        .widthIn(max = 280.dp),
                                    colors = CardDefaults.cardColors(
                                        containerColor = if (isUser) MattePurple else CardCharcoal
                                    ),
                                    border = if (isUser) null else BorderStroke(1.dp, BorderAccent),
                                    shape = RoundedCornerShape(
                                        topStart = 16.dp,
                                        topEnd = 16.dp,
                                        bottomStart = if (isUser) 16.dp else 4.dp,
                                        bottomEnd = if (isUser) 4.dp else 16.dp
                                    )
                                ) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        if (message.imageBase64 != null) {
                                            val bitmap = remember(message.imageBase64) {
                                                try {
                                                    val imageBytes = Base64.decode(message.imageBase64, Base64.DEFAULT)
                                                    BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.size)?.asImageBitmap()
                                                } catch (e: Exception) {
                                                    null
                                                }
                                            }
                                            if (bitmap != null) {
                                                Image(
                                                    bitmap = bitmap,
                                                    contentDescription = "Generated image",
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .aspectRatio(1f)
                                                        .clip(RoundedCornerShape(8.dp)),
                                                    contentScale = ContentScale.Crop
                                                )
                                                Spacer(modifier = Modifier.height(8.dp))
                                            }
                                        }

                                        Text(
                                            text = message.message,
                                            color = TextLight,
                                            fontSize = 15.sp,
                                            lineHeight = 20.sp
                                        )
                                    }
                                }
                            }
                        }
                    }

                    if (isLoading) {
                        item {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.Start,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(34.dp)
                                        .clip(CircleShape)
                                        .border(1.dp, NeonCyan, CircleShape)
                                ) {
                                    AsyncImage(
                                        model = botAvatarUri ?: R.drawable.cool_axolote_avatar_1782170240859,
                                        contentDescription = "Axolote Bot",
                                        modifier = Modifier.fillMaxSize(),
                                        contentScale = ContentScale.Crop
                                    )
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Box(
                                    modifier = Modifier
                                        .background(CardCharcoal, RoundedCornerShape(12.dp))
                                        .border(1.dp, BorderAccent, RoundedCornerShape(12.dp))
                                        .padding(horizontal = 14.dp, vertical = 10.dp)
                                ) {
                                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Text("pensando...", color = NeonCyan, fontSize = 13.sp)
                                    }
                                }
                            }
                        }
                    }
                }

                // Keyboard message row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(CardCharcoal)
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                        .navigationBarsPadding()
                        .imePadding(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextField(
                        value = textInput,
                        onValueChange = { textInput = it },
                        placeholder = {
                            Text(
                                "peça ao axolote bot",
                                color = TextLight.copy(alpha = 0.5f)
                            )
                        },
                        modifier = Modifier
                            .weight(1.0f)
                            .clip(RoundedCornerShape(24.dp))
                            .background(DarkNavy),
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = DarkNavy,
                            unfocusedContainerColor = DarkNavy,
                            disabledContainerColor = DarkNavy,
                            focusedIndicatorColor = Color.Transparent,
                            unfocusedIndicatorColor = Color.Transparent,
                            focusedTextColor = TextLight,
                            unfocusedTextColor = TextLight
                        ),
                        singleLine = false,
                        maxLines = 4
                    )

                    Spacer(modifier = Modifier.width(8.dp))
                    
                    IconButton(
                        onClick = {
                            if (textInput.isNotBlank() && !isLoading) {
                                viewModel.generateImage(textInput)
                                textInput = ""
                                keyboardController?.hide()
                            }
                        },
                        enabled = textInput.isNotBlank() && !isLoading,
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(if (textInput.isNotBlank() && !isLoading) NeonCyan else BorderAccent),
                        colors = IconButtonDefaults.iconButtonColors(contentColor = DarkNavy)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Image,
                            contentDescription = "Gerar Imagem",
                            tint = if (textInput.isNotBlank() && !isLoading) DarkNavy else TextLight.copy(alpha = 0.4f)
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    IconButton(
                        onClick = {
                            if (textInput.isNotBlank() && !isLoading) {
                                viewModel.sendMessage(textInput)
                                textInput = ""
                                keyboardController?.hide()
                            }
                        },
                        enabled = textInput.isNotBlank() && !isLoading,
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(if (textInput.isNotBlank() && !isLoading) NeonCyan else BorderAccent),
                        colors = IconButtonDefaults.iconButtonColors(contentColor = DarkNavy)
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Send,
                            contentDescription = "Enviar",
                            tint = if (textInput.isNotBlank() && !isLoading) DarkNavy else TextLight.copy(alpha = 0.4f)
                        )
                    }
                }
            }
        }
    }

    // Modal Dialog to edit username
    if (showsNameDialog) {
        AlertDialog(
            onDismissRequest = { showsNameDialog = false },
            containerColor = CardCharcoal,
            title = {
                Text(
                    text = "Como o Axolote Bot deve te chamar?",
                    color = NeonCyan,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
            },
            text = {
                Column {
                    Text(
                        text = "Escolha um nome. Ele vai zombar de qualquer jeito, mas pelo menos use algo criativo.",
                        fontSize = 13.sp,
                        color = TextLight.copy(alpha = 0.8f)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = currentNameInput,
                        onValueChange = { currentNameInput = it },
                        modifier = Modifier.fillMaxWidth(),
                        textStyle = LocalTextStyle.current.copy(color = TextLight),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextLight,
                            unfocusedTextColor = TextLight,
                            focusedBorderColor = NeonCyan,
                            unfocusedBorderColor = BorderAccent
                        )
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (currentNameInput.isNotBlank()) {
                            viewModel.setUsername(currentNameInput)
                        }
                        showsNameDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NeonCyan, contentColor = DarkNavy)
                ) {
                    Text("Salvar Apelido", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showsNameDialog = false },
                    colors = ButtonDefaults.textButtonColors(contentColor = TextLight.copy(alpha = 0.6f))
                ) {
                    Text("Cancelar")
                }
            }
        )
    }
}
}
