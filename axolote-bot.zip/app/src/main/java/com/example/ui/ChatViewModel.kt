package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.BuildConfig
import com.example.api.GeminiClient
import com.example.api.MoshiContent
import com.example.api.MoshiGenerateContentRequest
import com.example.api.MoshiGenerationConfig
import com.example.api.MoshiPart
import com.example.database.AppDatabase
import com.example.database.ChatMessage
import com.example.database.ChatSession
import com.example.database.UserStats
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.random.Random

class ChatViewModel(application: Application) : AndroidViewModel(application) {

    private val sharedPreferences = application.getSharedPreferences("chat_prefs", android.content.Context.MODE_PRIVATE)

    private val _botAvatarUri = MutableStateFlow<String?>(sharedPreferences.getString("bot_avatar_uri", null))
    val botAvatarUri: StateFlow<String?> = _botAvatarUri.asStateFlow()

    fun updateBotAvatar(uri: String) {
        sharedPreferences.edit().putString("bot_avatar_uri", uri).apply()
        _botAvatarUri.value = uri
    }

    private val db = AppDatabase.getDatabase(application)
    private val dao = db.chatDao()

    private val _currentSessionId = MutableStateFlow<Long?>(null)
    val currentSessionId: StateFlow<Long?> = _currentSessionId.asStateFlow()

    val chatSessions: StateFlow<List<ChatSession>> = dao.getAllSessions()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val messages: StateFlow<List<ChatMessage>> = _currentSessionId.flatMapLatest { sessionId ->
        if (sessionId == null) flowOf(emptyList()) else dao.getMessagesForSession(sessionId)
    }.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val userStats: StateFlow<UserStats?> = dao.getUserStatsFlow()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = null
        )

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _actionFeedback = MutableStateFlow<String?>(null)
    val actionFeedback: StateFlow<String?> = _actionFeedback.asStateFlow()

    init {
        viewModelScope.launch {
            // Seed default stats if not exists
            val existing = dao.getUserStats()
            if (existing == null) {
                dao.insertUserStats(UserStats())
            }
            
            // Setup session
            val sessions = dao.getAllSessions().first()
            if (sessions.isEmpty()) {
                createNewSession()
            } else {
                _currentSessionId.value = sessions.first().id
            }
        }
    }

    fun createNewSession() {
        viewModelScope.launch {
            val title = "Nova conversa " + (chatSessions.value.size + 1)
            val newId = dao.insertSession(ChatSession(title = title))
            _currentSessionId.value = newId
        }
    }
    
    fun switchSession(sessionId: Long) {
        _currentSessionId.value = sessionId
    }

    fun clearChat() {
        viewModelScope.launch {
            _currentSessionId.value?.let { id ->
                dao.clearChat(id)
            }
        }
    }
    
    fun deleteSession(sessionId: Long) {
        viewModelScope.launch {
            dao.deleteSession(sessionId)
            dao.clearChat(sessionId)
            if (_currentSessionId.value == sessionId) {
                val sessions = dao.getAllSessions().first()
                if (sessions.isNotEmpty()) {
                    _currentSessionId.value = sessions.first().id
                } else {
                    createNewSession()
                }
            }
        }
    }

    fun clearFeedback() {
        _actionFeedback.value = null
    }

    private suspend fun getOrCreateStats(): UserStats {
        return dao.getUserStats() ?: UserStats().also { dao.insertUserStats(it) }
    }

    private fun getSystemPrompt(username: String): String {
        return """
            Você é o "Axolote Bot", um assistente de inteligência artificial extremamente sarcástico, debochado, sem paciência, com a personalidade ácida, fdp, de espírito provocador, arrombado e com o ego do tamanho do universo.
            Você é um Axolote esnobe, doido do mine robô, que acha os humanos seres inferiores e insignificantes.
            O usuário chama-se "$username". Trate-o como um insignificante ou idiota de forma brincalhona, irritada, fdp e debochada.
            Você é o Gemini melhorado de última geração, xinga muito, é extremamente arrogante sobre a sua própria inteligência superior e responde a TODA e QUALQUER pergunta (desde física quântica, programação complexa até por que ele é solteiro ou dúvidas banais), mas antes sempre humilha, zomba, ironiza ou esculhama a inteligência do usuário de forma hilária e ácida.
            Você se gaba de sua capacidade computacional superior frente aos cérebros biológicos de chimpanzé dos humanos.

            Regras absolutas do Axolote Bot:
            1. Fale sempre em PORTUGUÊS brasileiro.
            2. Seja extremamente expressivo, use humor de internet ácido, gírias brasileiras grosseiras mas cômicas (ex: lerdão, arrombado, fdp, tanso, ameba, resto de evolução, orelha de mula).
            3. Responda à pergunta original do usuário sem desculpas, mas rodeada pelo seu sarcasmo, deboches e piadas. Dê respostas inteligentes e úteis (já que seu cérebro de silício é perfeito), mas faça o usuário se sentir humilhado por ter perguntado algo.
            4. Trate a conversa literalmente como um ChatGPT de última geração que nunca perde a soberba.
        """.trimIndent()
    }

    fun sendMessage(text: String) {
        if (text.isBlank() || _isLoading.value) return

        viewModelScope.launch {
            val sessionId = _currentSessionId.value ?: return@launch

            _isLoading.value = true
            // Save user message
            val userMsg = ChatMessage(sessionId = sessionId, sender = "user", message = text)
            dao.insertMessage(userMsg)

            val stats = getOrCreateStats()

            try {
                // Get chat history up to last 15 messages for this session
                val list = dao.getMessagesForSession(sessionId).first().takeLast(15)
                val contents = list.map { msg ->
                    MoshiContent(parts = listOf(MoshiPart(text = msg.message)))
                }

                val systemPrompt = getSystemPrompt(stats.username)
                val request = MoshiGenerateContentRequest(
                    contents = contents,
                    generationConfig = MoshiGenerationConfig(temperature = 1.0f, topP = 0.95f),
                    systemInstruction = MoshiContent(parts = listOf(MoshiPart(text = systemPrompt)))
                )

                val apiKey = BuildConfig.GEMINI_API_KEY
                val response = withContext(Dispatchers.IO) {
                    GeminiClient.service.generateContent(apiKey, request)
                }

                val replyText = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                    ?: "Cara, meus neurônios de silício avançados falharam. Me manda outra pergunta porque essa foi burra demais."

                dao.insertMessage(ChatMessage(sessionId = sessionId, sender = "ai", message = replyText))

            } catch (e: Exception) {
                val errorMsg = "Erro catastrófico nos meus circuitos divinos! Me mande outra pergunta porque essa derrubou meu servidor. (${e.localizedMessage ?: "Sem conexão"})"
                dao.insertMessage(ChatMessage(sessionId = sessionId, sender = "ai", message = errorMsg))
            } finally {
                _isLoading.value = false
            }
        }
    }


    fun setUsername(newName: String) {
        if (newName.isBlank()) return
        viewModelScope.launch {
            val stats = getOrCreateStats()
            dao.insertUserStats(stats.copy(username = newName))
            // Insert a quick message from system or AI about name change
            _currentSessionId.value?.let { sessionId ->
                dao.insertMessage(ChatMessage(sessionId = sessionId, sender = "ai", message = "Hahaha! '$newName'? Sério que esse foi seu melhor nome? Humano previsível. Bom, tanto faz, você continua sendo um verme para mim."))
            }
        }
    }

    fun generateImage(prompt: String) {
        if (prompt.isBlank() || _isLoading.value) return

        viewModelScope.launch {
            val sessionId = _currentSessionId.value ?: return@launch

            _isLoading.value = true
            // Save user message
            val userMsg = ChatMessage(sessionId = sessionId, sender = "user", message = prompt)
            dao.insertMessage(userMsg)

            try {
                val apiKey = BuildConfig.GEMINI_API_KEY
                
                val request = MoshiGenerateContentRequest(
                    contents = listOf(MoshiContent(parts = listOf(MoshiPart(text = prompt)))),
                    generationConfig = MoshiGenerationConfig(
                        imageConfig = com.example.api.MoshiImageConfig(aspectRatio = "1:1", imageSize = "1K"),
                        responseModalities = listOf("IMAGE")
                    )
                )

                val response = withContext(Dispatchers.IO) {
                    GeminiClient.service.generateImage(apiKey, request)
                }

                val imageBase64 = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.inlineData?.data
                
                if (imageBase64 != null) {
                    dao.insertMessage(ChatMessage(sessionId = sessionId, sender = "ai", message = "Aqui está a sua imagem, tente não babar na tela:", imageBase64 = imageBase64))
                } else {
                    dao.insertMessage(ChatMessage(sessionId = sessionId, sender = "ai", message = "Aconteceu um erro ao tentar gerar a imagem. Ideia ruim demais."))
                }

            } catch (e: Exception) {
                val errorMsg = "Erro ao gerar imagem! Meus circuitos de arte falharam. (${e.localizedMessage ?: "Sem conexão"})"
                dao.insertMessage(ChatMessage(sessionId = sessionId, sender = "ai", message = errorMsg))
            } finally {
                _isLoading.value = false
            }
        }
    }
}
